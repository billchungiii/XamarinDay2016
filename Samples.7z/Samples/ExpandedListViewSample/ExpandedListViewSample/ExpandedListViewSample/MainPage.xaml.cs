﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ExpandedListViewSample
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            this.BindingContext = GetData();
        }



        public People GetData()
        {
            People people = new People();
            people.Items.Add(new Person() { Name = "Bill", Age = 45 });
            people.Items.Add(new Person() { Name = "David", Age = 42 });
            people.Items.Add(new Person() { Name = "John", Age = 40 });
            people.Items.Add(new Person() { Name = "Tom", Age = 48 });
            return people;
        }
    }
}
