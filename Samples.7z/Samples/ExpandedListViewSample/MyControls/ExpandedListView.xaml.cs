﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Reflection;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace MyControls
{
   
    public partial class ExpandedListView : TemplatedView
    {
        public ExpandedListView()
        {
            InitializeComponent();           
        }

        //ItemTemplate
        public static readonly BindableProperty ItemTemplateProperty =
            BindableProperty.Create("ItemTemplate",
                                     typeof(DataTemplate),
                                     typeof(ExpandedListView),
                                     null,
                                     BindingMode.TwoWay,
                                     null,
                                     null);

        public DataTemplate ItemTemplate
        {
            get { return (DataTemplate)GetValue(ItemTemplateProperty); }
            set { SetValue(ItemTemplateProperty, value); }
        }

        //ItemSource
        public static readonly BindableProperty ItemSourceProperty =
      BindableProperty.Create("ItemSource",
                               typeof(IEnumerable),
                               typeof(ExpandedListView),
                               null,
                               BindingMode.TwoWay,
                               null,
                               null);

        public IEnumerable ItemSource
        {
            get { return (IEnumerable)GetValue(ItemSourceProperty); }
            set { SetValue(ItemSourceProperty, value); }
        }


        // Visibility
        public static readonly BindableProperty VisibilityProperty =
       BindableProperty.Create("Visibility",
                                typeof(bool),
                                typeof(ExpandedListView),
                                false,
                                BindingMode.OneWay,
                                null,
                                null);



        public bool Visibility
        {
            get { return (bool)GetValue(VisibilityProperty); }
            private set
            { SetValue(VisibilityProperty, value);}
        }


        //Title
        public static readonly BindableProperty TitleProperty =
       BindableProperty.Create("Title",
                               typeof(View),
                               typeof(ExpandedListView),
                               null,
                               BindingMode.TwoWay,
                               null,
                               null);


        public View Title
        {
            get { return (View)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }



        private void OnImageTapped(object sender, EventArgs e)
        {

            Visibility = !Visibility;
            RotateImage((Image)sender);
        }

        private void RotateImage(Image image)
        {
            if (Visibility)
            {
                image.RotateTo(90);
            }
            else
            {
                image.RotateTo(0);
            }
        }
    }
}
