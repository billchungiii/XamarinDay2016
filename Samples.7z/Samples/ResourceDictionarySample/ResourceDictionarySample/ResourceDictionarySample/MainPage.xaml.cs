﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ResourceDictionarySample
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            foreach (var r in  grid.Resources )
            {
                Debug.WriteLine(r.Key + ":" + r.Value.ToString());
            } 
            base.OnAppearing();
        }
    }
}
