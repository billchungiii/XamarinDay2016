﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace CombineAnimationsSample
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            image.Source = ImageSource.FromResource("CombineAnimationsSample.test2.png");

        }

         private void Compound_Clicked(object sender, EventArgs e)
        {
             CompoundAnimation();
        }

        async private void CompoundAnimation()
        {
            await image.TranslateTo(50, 50, 2000, Easing.CubicOut);
            await image.RotateTo(45, 2000, Easing.CubicOut);
        }


        private void Composite_Clicked(object sender, EventArgs e)
        {
            CompositAnimation();
        }

        private void CompositAnimation()
        {
            image.TranslateTo(50, 50, 2000, Easing.CubicOut);
            image.RotateTo(45, 2000, Easing.CubicOut);
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            image.TranslateTo(0, 0, 0, null);
            image.RotateTo(0, 0, null);

        }

    }
}
