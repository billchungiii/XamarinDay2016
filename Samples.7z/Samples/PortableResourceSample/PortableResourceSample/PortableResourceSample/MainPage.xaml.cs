﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace PortableResourceSample
{
    [XamlCompilation(XamlCompilationOptions.Skip )]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            //labelXX.TextColor = (Color)App.Current.Resources["BackColor"];  
            Debug.WriteLine("Main Page Created!!");
           
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            foreach (var r in App.Current.Resources)
            {
                Debug.WriteLine(r.Key + "--" + r.Value.ToString());
            }

            Debug.WriteLine(App.Current.Resources.Count);
        }
    }
}
